import React, { useState, useEffect, useRef } from "react";
import * as THREE from "three";
import { ResponsiveContainer, AreaChart, Area, YAxis, Tooltip } from "recharts";

// ---------- Design tokens (Precision & Utility) ----------
const C = {
  canvas: "#111418",
  surface: "#1B222B",
  cyan: "#00C2CB",
  ember: "#E05A47",
  textPrimary: "#F8FAFC",
  textSecondary: "#94A3B8",
  border: "rgba(255,255,255,0.08)",
  innerHighlight: "inset 0 1px 0 rgba(255,255,255,0.06)",
  usGreen: "#3FBF6F",
  natoBlue: "#4E8FE0",
};

const display = "'Orbitron', 'Space Grotesk', sans-serif";
const body = "'Inter', 'Plus Jakarta Sans', sans-serif";
const mono = "'JetBrains Mono', monospace";

const RADIUS_SM = 8;

// ---------- Data ----------
const CONFLICTS = [
  {
    id: "sahel-01",
    name: "Sahel corridor",
    region: "West Africa",
    theater: "global",
    severity: "high",
    score: 8.4,
    breakdown: { volume: 5.2, keyword: 2.1, tone: 1.1 },
    confidence: "normal",
    trend: "up",
    lat: 16.3,
    lon: -0.05,
    updated: "4m",
    history: [4.8, 5.1, 5.6, 6.0, 6.9, 7.6, 8.4],
    summary:
      "Militia clashes near Gao intersect with a contested convoy route; three border posts reported unreachable since 03:10 UTC.",
    timeline: [
      { t: "03:10", e: "Border post comms drop, Gao–Ansongo road" },
      { t: "05:40", e: "Unconfirmed reports of armed movement, sat imagery pending" },
      { t: "07:55", e: "Regional bloc calls emergency session" },
    ],
    sources: [
      { label: "Telegram — regional monitor", conf: "medium" },
      { label: "Sentinel-2 pass, 06:12 UTC", conf: "high" },
      { label: "Wire stringer, unverified", conf: "low" },
    ],
  },
  {
    id: "taiwan-strait",
    name: "Taiwan Strait",
    region: "East Asia",
    theater: "global",
    severity: "elevated",
    score: 6.1,
    breakdown: { volume: 3.6, keyword: 1.6, tone: 0.9 },
    confidence: "high",
    trend: "flat",
    lat: 24.2,
    lon: 118.6,
    updated: "12m",
    history: [6.3, 6.0, 6.2, 5.9, 6.1, 6.0, 6.1],
    summary:
      "Median-line transits at monthly baseline; one additional coast-guard vessel logged near Kinmen, consistent with prior drill cadence.",
    timeline: [
      { t: "Yesterday", e: "Routine ADIZ transit, 9 aircraft logged" },
      { t: "02:00", e: "Coast guard vessel added near Kinmen" },
    ],
    sources: [
      { label: "MND daily brief", conf: "high" },
      { label: "AIS vessel tracking", conf: "high" },
    ],
  },
  {
    id: "donbas-line",
    name: "Eastern front line",
    region: "Eastern Europe",
    theater: "eastern-europe",
    severity: "high",
    score: 9.1,
    breakdown: { volume: 6.0, keyword: 2.4, tone: 0.7 },
    confidence: "high",
    trend: "up",
    lat: 48.3,
    lon: 37.8,
    updated: "1m",
    history: [6.8, 7.0, 7.4, 7.9, 8.3, 8.7, 9.1],
    summary:
      "Artillery activity up sharply near a logistics hub; two sourced but unverified reports of a strike on rail infrastructure.",
    timeline: [
      { t: "22:14", e: "Sustained artillery exchange reported, ~40km sector" },
      { t: "23:02", e: "Rail strike claimed by local channel, no imagery yet" },
      { t: "00:30", e: "Second source corroborates general location only" },
    ],
    sources: [
      { label: "OSINT aggregator feed", conf: "medium" },
      { label: "Local Telegram channel", conf: "low" },
      { label: "Local Telegram channel (2)", conf: "low" },
    ],
  },
  {
    id: "red-sea",
    name: "Red Sea shipping lane",
    region: "Middle East",
    theater: "middle-east",
    severity: "elevated",
    score: 5.8,
    breakdown: { volume: 3.9, keyword: 1.4, tone: 0.5 },
    confidence: "high",
    trend: "down",
    lat: 15.6,
    lon: 41.8,
    updated: "31m",
    history: [7.4, 7.1, 6.7, 6.4, 6.1, 5.9, 5.8],
    summary:
      "No intercepted vessels in 96 hours. Insurers have not moved war-risk premiums this week — first plateau since the corridor opened.",
    timeline: [
      { t: "Mon", e: "Last intercepted vessel, no casualties reported" },
      { t: "Wed", e: "Naval escort cadence unchanged" },
    ],
    sources: [{ label: "Maritime security bulletin", conf: "high" }],
  },
  {
    id: "kashmir-loc",
    name: "Line of Control",
    region: "South Asia",
    theater: "global",
    severity: "watch",
    score: 3.2,
    breakdown: { volume: 1.8, keyword: 1.0, tone: 0.4 },
    confidence: "normal",
    trend: "flat",
    lat: 34.2,
    lon: 74.3,
    updated: "2h",
    history: [3.4, 3.1, 3.3, 3.0, 3.3, 3.1, 3.2],
    summary:
      "Sporadic small-arms fire reported by both sides, within seasonal norms. No troop movement corroborated by satellite pass.",
    timeline: [{ t: "Yesterday", e: "Exchange of fire, both sides claim provocation" }],
    sources: [{ label: "Wire service", conf: "medium" }],
  },
  {
    id: "horn-africa",
    name: "Horn of Africa",
    region: "East Africa",
    theater: "global",
    severity: "watch",
    score: 2.9,
    breakdown: { volume: 1.1, keyword: 1.0, tone: 0.8 },
    confidence: "low",
    trend: "down",
    lat: 8.0,
    lon: 46.5,
    updated: "3h",
    history: [4.6, 4.1, 3.8, 3.5, 3.3, 3.0, 2.9],
    summary:
      "Ceasefire monitors report the fourth consecutive quiet week. Displacement camp population has begun to decline.",
    timeline: [{ t: "3 days ago", e: "Monitor mission extends mandate 90 days" }],
    sources: [{ label: "UN monitor statement", conf: "high" }],
  },
  {
    id: "gaza-strip",
    name: "Gaza Strip",
    region: "Middle East",
    theater: "middle-east",
    severity: "high",
    score: 8.9,
    breakdown: { volume: 6.4, keyword: 2.2, tone: 0.3 },
    confidence: "high",
    trend: "up",
    lat: 31.4,
    lon: 34.3,
    updated: "2m",
    history: [7.6, 7.8, 8.0, 8.3, 8.5, 8.7, 8.9],
    summary:
      "Airstrike activity reported in the northern sector overnight; Home Front Command sirens active in three border communities.",
    timeline: [
      { t: "01:20", e: "Sirens triggered, southern border communities" },
      { t: "02:05", e: "Airstrikes reported, unconfirmed target" },
      { t: "04:40", e: "Ceasefire monitors request access, denied" },
    ],
    sources: [
      { label: "Pikud HaOref mirror feed", conf: "high" },
      { label: "Wire service, Gaza stringer", conf: "medium" },
      { label: "Telegram — unverified", conf: "low" },
    ],
  },
  {
    id: "kharkiv-front",
    name: "Kharkiv sector",
    region: "Eastern Europe",
    theater: "eastern-europe",
    severity: "elevated",
    score: 6.7,
    breakdown: { volume: 4.0, keyword: 1.8, tone: 0.9 },
    confidence: "normal",
    trend: "up",
    lat: 49.99,
    lon: 36.23,
    updated: "9m",
    history: [5.1, 5.4, 5.8, 6.0, 6.3, 6.5, 6.7],
    summary:
      "Shahed drone tracks reported entering from the northeast; regional air-raid alert active, no impacts confirmed yet.",
    timeline: [
      { t: "23:40", e: "Oblast air-raid alert issued" },
      { t: "00:15", e: "Drone tracks logged, heading southwest" },
    ],
    sources: [
      { label: "Oblast alert feed", conf: "high" },
      { label: "Drone tracker (community)", conf: "medium" },
    ],
  },
];

// Country Instability Index (CII) — a slower-moving, country-level stress
// score distinct from the sharper per-conflict severity above. Modeled on
// worldmonitor's CII concept: a persistent baseline, not an event score.
const CII = [
  { code: "ML", name: "Mali", score: 8.1, delta: 0.6 },
  { code: "UA", name: "Ukraine", score: 8.8, delta: 0.3 },
  { code: "IL", name: "Israel", score: 7.9, delta: 0.4 },
  { code: "SD", name: "Sudan", score: 7.4, delta: 0.1 },
  { code: "MM", name: "Myanmar", score: 6.6, delta: -0.2 },
  { code: "PK", name: "Pakistan", score: 5.3, delta: 0.0 },
  { code: "SO", name: "Somalia", score: 5.0, delta: -0.5 },
  { code: "TW", name: "Taiwan", score: 4.2, delta: 0.1 },
];

// Military installations (illustrative subset, not a complete order of battle).
// Alliance affiliation drives marker color: US = green, NATO = blue.
const MILITARY_BASES = [
  { id: "ramstein", name: "Ramstein Air Base", country: "Germany", alliance: "nato", lat: 49.44, lon: 7.6 },
  { id: "incirlik", name: "Incirlik Air Base", country: "Türkiye", alliance: "nato", lat: 37.0, lon: 35.43 },
  { id: "diego-garcia", name: "Diego Garcia", country: "British Indian Ocean Territory", alliance: "us", lat: -7.31, lon: 72.41 },
  { id: "al-udeid", name: "Al Udeid Air Base", country: "Qatar", alliance: "us", lat: 25.12, lon: 51.32 },
  { id: "yokota", name: "Yokota Air Base", country: "Japan", alliance: "us", lat: 35.75, lon: 139.35 },
  { id: "rota", name: "Naval Station Rota", country: "Spain", alliance: "nato", lat: 36.62, lon: -6.35 },
  { id: "bagram-legacy", name: "Bagram (former)", country: "Afghanistan", alliance: "us", lat: 34.94, lon: 69.26 },
  { id: "camp-lemonnier", name: "Camp Lemonnier", country: "Djibouti", alliance: "us", lat: 11.54, lon: 43.15 },
];

// Country-level dossiers (Current vs Historical conflicts) — keyed by CII
// country code so the CII strip can open straight into a country's record.
const COUNTRY_DOSSIERS = {
  ML: {
    name: "Mali",
    current: [
      { title: "Sahel corridor militia clashes", period: "2026–ongoing", note: "Convoy route contested near Gao" },
      { title: "JNIM insurgent activity", period: "2023–ongoing", note: "Rural governance contested in central regions" },
    ],
    historical: [
      { title: "Tuareg rebellion (2012)", period: "2012", note: "Led to northern territorial split, later reversed" },
      { title: "French Operation Serval", period: "2013", note: "Intervention against militant advance on Bamako" },
    ],
  },
  UA: {
    name: "Ukraine",
    current: [
      { title: "Eastern front line", period: "2022–ongoing", note: "Active artillery and drone exchange, Donbas sector" },
      { title: "Kharkiv sector drone activity", period: "2026", note: "Regional air-raid alerts, Shahed tracks" },
    ],
    historical: [
      { title: "Annexation of Crimea", period: "2014", note: "Disputed under international law" },
      { title: "Euromaidan", period: "2013–2014", note: "Domestic political uprising, change of government" },
    ],
  },
  IL: {
    name: "Israel",
    current: [
      { title: "Gaza Strip airstrike activity", period: "2023–ongoing", note: "Northern sector strikes, ceasefire monitor access denied" },
    ],
    historical: [
      { title: "Yom Kippur War", period: "1973", note: "Multi-front war with Egypt and Syria" },
      { title: "Six-Day War", period: "1967", note: "Territorial changes still contested today" },
    ],
  },
};

const TICKER = [
  "03:41 UTC — sat pass confirms no new fortification, sector 4",
  "03:38 UTC — regional bloc statement expected within the hour",
  "03:35 UTC — vessel tracking: 2 tankers rerouted, Red Sea approach",
  "03:29 UTC — unconfirmed: comms restored, Gao–Ansongo road",
  "03:22 UTC — wire: no casualties reported in overnight exchange",
  "03:15 UTC — analyst note added, eastern front line",
];

// High/elevated read on the Ember scale (critical → warning); Watch reads on
// Cyan (the system's "stable, monitoring" signal, not an alert color).
const SEV_META = {
  high: { color: C.ember, label: "High" },
  elevated: { color: "#B97355", label: "Elevated" },
  watch: { color: C.cyan, label: "Watch" },
};

const TREND_GLYPH = { up: "↑", down: "↓", flat: "→" };

// Confidence tiers (mirrors global-activity-monitor's source-diversity tiers):
// low = satellite/geo-only, no article corroboration yet.
const CONF_META = {
  high: { label: "High confidence", opacity: 1 },
  normal: { label: "Normal confidence", opacity: 0.85 },
  low: { label: "Low confidence — satellite/geo only", opacity: 0.55 },
};

// ---------- Small components ----------

function SeverityDot({ severity, size = 8 }) {
  const m = SEV_META[severity];
  return (
    <span
      style={{
        display: "inline-block",
        width: size,
        height: size,
        borderRadius: "50%",
        background: m.color,
        flexShrink: 0,
      }}
    />
  );
}

function ConfBar({ conf }) {
  const map = { high: 3, medium: 2, low: 1 };
  const n = map[conf];
  return (
    <span style={{ display: "inline-flex", gap: 2, alignItems: "flex-end", height: 9 }}>
      {[1, 2, 3].map((i) => (
        <span
          key={i}
          style={{
            width: 3,
            height: i * 3,
            borderRadius: 1,
            background: i <= n ? C.textSecondary : "rgba(255,255,255,0.1)",
          }}
        />
      ))}
    </span>
  );
}

function RegionRow({ c, active, onClick }) {
  const m = SEV_META[c.severity];
  const conf = CONF_META[c.confidence] || CONF_META.normal;
  return (
    <button
      onClick={onClick}
      style={{
        width: "100%",
        textAlign: "left",
        background: active ? C.surface : "transparent",
        border: "none",
        borderLeft: active ? `2px solid ${m.color}` : "2px solid transparent",
        borderBottom: `1px solid ${C.border}`,
        padding: "11px 14px 11px 12px",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        gap: 5,
        fontFamily: body,
        opacity: conf.opacity,
        transition: "background 150ms ease-out, border-color 150ms ease-out",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <SeverityDot severity={c.severity} />
          <span style={{ color: C.textPrimary, fontSize: 13, fontWeight: 500 }}>{c.name}</span>
          {c.confidence === "low" && (
            <span
              style={{
                fontSize: 9,
                fontFamily: mono,
                color: C.textSecondary,
                border: `1px dashed ${C.border}`,
                borderRadius: 3,
                padding: "0 4px",
              }}
            >
              unconf.
            </span>
          )}
        </div>
        <span style={{ fontFamily: mono, fontSize: 11, color: C.textSecondary }}>{c.updated}</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingLeft: 15 }}>
        <span style={{ fontSize: 11.5, color: C.textSecondary }}>{c.region}</span>
        <span
          style={{
            fontFamily: mono,
            fontSize: 11.5,
            color: m.color,
            display: "flex",
            gap: 4,
            alignItems: "center",
            fontWeight: 500,
          }}
        >
          {c.score.toFixed(1)}
          <span style={{ color: c.trend === "up" ? C.ember : c.trend === "down" ? C.cyan : C.textSecondary }}>
            {TREND_GLYPH[c.trend]}
          </span>
        </span>
      </div>
    </button>
  );
}

// Convert lat/lon (degrees) to a point on a sphere of given radius.
// Three.js convention: +Y up, +Z toward viewer at lon=0.
function latLonToVec3(lat, lon, radius) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

// Rough continental outlines as lat/lon polylines (simplified, not survey-grade)
// — enough coastline shape to read as "Earth" without a texture asset.
const COASTLINES = [
  // Africa
  [[37,-9],[35,10],[31,32],[12,43],[-1,42],[-16,35],[-26,33],[-34,20],[-33,18],[-28,16],[-17,11],[4,9],[6,-5],[15,-17],[21,-17],[28,-11],[35,-6],[37,-9]],
  // Europe
  [[36,-6],[43,-9],[49,-1],[51,3],[59,11],[65,14],[71,26],[70,35],[59,30],[54,20],[47,17],[41,20],[36,-6]],
  // Asia (broad)
  [[40,26],[47,40],[55,49],[66,60],[73,80],[75,110],[68,140],[60,163],[43,145],[35,129],[22,113],[13,109],[8,98],[13,80],[25,67],[37,50],[40,26]],
  // North America
  [[70,-160],[71,-125],[60,-95],[49,-95],[49,-123],[33,-117],[25,-97],[30,-81],[45,-67],[60,-65],[70,-160]],
  // South America
  [[11,-72],[10,-62],[-3,-51],[-23,-43],[-34,-58],[-52,-69],[-38,-73],[-18,-70],[-4,-81],[11,-72]],
  // Australia
  [[-11,131],[-17,146],[-28,153],[-38,145],[-35,137],[-32,115],[-20,113],[-11,131]],
];

// Purely cosmetic visual modes for the globe panel — palette + CSS filter
// swaps only. No new data, no tracking capability; same conflicts, same
// markers, same interactions in every mode.
const VISUAL_MODES = {
  default: {
    label: "DEFAULT",
    sphere: C.surface,
    rim: C.cyan,
    rimOpacity: 0.06,
    coastline: C.textSecondary,
    graticule: "#ffffff",
    cssFilter: "none",
    scanlines: false,
  },
  satellite: {
    label: "SATELLITE",
    sphere: "#1a2f1c",
    rim: "#5fae6a",
    rimOpacity: 0.08,
    coastline: "#8fd39a",
    graticule: "#ffffff",
    cssFilter: "saturate(1.15) contrast(1.05)",
    scanlines: false,
  },
  flir: {
    label: "FLIR",
    sphere: "#241018",
    rim: "#ff8a3d",
    rimOpacity: 0.1,
    coastline: "#ffb366",
    graticule: "#ff8a3d",
    cssFilter: "grayscale(1) invert(1) contrast(1.1)",
    scanlines: false,
  },
  nvg: {
    label: "NVG",
    sphere: "#0c1a0c",
    rim: "#5aff6e",
    rimOpacity: 0.12,
    coastline: "#8fff9c",
    graticule: "#5aff6e",
    cssFilter: "grayscale(1) sepia(1) hue-rotate(70deg) saturate(4) brightness(0.9)",
    scanlines: false,
  },
  crt: {
    label: "CRT",
    sphere: "#0a1f14",
    rim: "#3dff8f",
    rimOpacity: 0.1,
    coastline: "#3dff8f",
    graticule: "#3dff8f",
    cssFilter: "sepia(0.3) hue-rotate(60deg) saturate(1.6) brightness(0.95)",
    scanlines: true,
  },
};
const VISUAL_MODE_ORDER = ["default", "satellite", "flir", "nvg", "crt"];

function Globe3D({ conflicts, selectedId, onSelect, showBases, visualMode }) {
  const mountRef = useRef(null);
  const stateRef = useRef({});
  const mode = VISUAL_MODES[visualMode] || VISUAL_MODES.default;

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    // Guard against a zero-size container on first paint (common in flex
    // layouts where this effect can fire before layout has settled) — fall
    // back to sane defaults rather than creating a 0x0 renderer that draws
    // nothing with no visible error.
    const width = mount.clientWidth || 640;
    const height = mount.clientHeight || 480;
    const RADIUS = 2;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0, 5.6);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mount.appendChild(renderer.domElement);

    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // Base sphere (ocean)
    const sphereGeo = new THREE.SphereGeometry(RADIUS, 64, 64);
    const sphereMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(mode.sphere),
      transparent: true,
      opacity: 0.9,
    });
    const sphere = new THREE.Mesh(sphereGeo, sphereMat);
    globeGroup.add(sphere);

    // Inner glow rim
    const rimGeo = new THREE.SphereGeometry(RADIUS * 1.015, 64, 64);
    const rimMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color(mode.rim),
      transparent: true,
      opacity: mode.rimOpacity,
      side: THREE.BackSide,
    });
    globeGroup.add(new THREE.Mesh(rimGeo, rimMat));

    // Lat/lon graticule
    const graticuleMat = new THREE.LineBasicMaterial({
      color: new THREE.Color(mode.graticule),
      transparent: true,
      opacity: 0.08,
    });
    for (let lat = -60; lat <= 60; lat += 30) {
      const pts = [];
      for (let lon = -180; lon <= 180; lon += 4) pts.push(latLonToVec3(lat, lon, RADIUS * 1.001));
      globeGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), graticuleMat));
    }
    for (let lon = -180; lon <= 180; lon += 30) {
      const pts = [];
      for (let lat = -90; lat <= 90; lat += 4) pts.push(latLonToVec3(lat, lon, RADIUS * 1.001));
      globeGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), graticuleMat));
    }

    // Coastlines
    const coastMat = new THREE.LineBasicMaterial({
      color: new THREE.Color(mode.coastline),
      transparent: true,
      opacity: 0.55,
    });
    COASTLINES.forEach((poly) => {
      const pts = poly.map(([lat, lon]) => latLonToVec3(lat, lon, RADIUS * 1.003));
      globeGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), coastMat));
    });

    // Hotspot markers (+ pulsing ring for the selected one).
    // Confidence tiers dim/shrink low-confidence markers and swap their
    // static ring for a dashed outline — mirrors how satellite-only
    // situations (no article corroboration) should read as provisional.
    const markerObjects = [];
    conflicts.forEach((c) => {
      const m = SEV_META[c.severity];
      const conf = CONF_META[c.confidence] || CONF_META.normal;
      const pos = latLonToVec3(c.lat, c.lon, RADIUS * 1.01);
      const color = new THREE.Color(m.color);
      const dotScale = c.confidence === "low" ? 0.72 : c.confidence === "normal" ? 0.88 : 1;

      const dotGeo = new THREE.SphereGeometry(0.032 * dotScale, 12, 12);
      const dotMat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: conf.opacity });
      const dot = new THREE.Mesh(dotGeo, dotMat);
      dot.position.copy(pos);
      dot.userData.id = c.id;
      globeGroup.add(dot);
      markerObjects.push(dot);

      if (c.confidence === "low") {
        // Dashed static outline for low-confidence (unconfirmed) situations.
        const dashPts = [];
        const segs = 24;
        for (let i = 0; i <= segs; i++) {
          const a = (i / segs) * Math.PI * 2;
          dashPts.push(new THREE.Vector3(Math.cos(a) * 0.052, Math.sin(a) * 0.052, 0));
        }
        const dashGeo = new THREE.BufferGeometry().setFromPoints(dashPts);
        dashGeo.computeBoundingSphere();
        const dashMat = new THREE.LineDashedMaterial({
          color,
          transparent: true,
          opacity: 0.5,
          dashSize: 0.012,
          gapSize: 0.01,
        });
        const dashLine = new THREE.LineLoop(dashGeo, dashMat);
        dashLine.computeLineDistances();
        dashLine.position.copy(pos);
        dashLine.lookAt(pos.clone().multiplyScalar(2));
        globeGroup.add(dashLine);
      }

      const ringGeo = new THREE.RingGeometry(0.05, 0.052, 32);
      const ringMat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0.7,
        side: THREE.DoubleSide,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.position.copy(pos);
      ring.lookAt(pos.clone().multiplyScalar(2));
      ring.userData.isRing = true;
      ring.userData.id = c.id;
      ring.userData.baseScale = 1;
      globeGroup.add(ring);
      markerObjects.push(ring);
    });

    // Military installations — small squares, distinct shape from the round
    // conflict markers so the two datasets never get confused at a glance.
    // Color carries alliance (US green / NATO blue), not severity.
    if (showBases) {
      MILITARY_BASES.forEach((b) => {
        const pos = latLonToVec3(b.lat, b.lon, RADIUS * 1.01);
        const color = new THREE.Color(b.alliance === "us" ? C.usGreen : C.natoBlue);
        const squareGeo = new THREE.PlaneGeometry(0.045, 0.045);
        const squareMat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, side: THREE.DoubleSide });
        const square = new THREE.Mesh(squareGeo, squareMat);
        square.position.copy(pos);
        square.lookAt(pos.clone().multiplyScalar(2));
        square.rotation.z = Math.PI / 4; // render as a diamond, reads clearly against the round dots
        globeGroup.add(square);
      });
    }

    // Ambient starfield (very sparse, subtle)
    const starGeo = new THREE.BufferGeometry();
    const starCount = 200;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const r = 20 + Math.random() * 10;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      starPos[i * 3 + 2] = r * Math.cos(phi);
    }
    starGeo.setAttribute("position", new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 0.035, transparent: true, opacity: 0.4 });
    scene.add(new THREE.Points(starGeo, starMat));

    // Initial orientation: bring roughly Africa/Europe to face camera
    globeGroup.rotation.y = 0.4;
    globeGroup.rotation.x = -0.15;

    // ---- Drag-to-rotate + click-to-select (no OrbitControls in r128 import path) ----
    let isDragging = false;
    let prevX = 0;
    let prevY = 0;
    let autoRotate = true;
    let velocityY = 0.0016;

    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();

    function onPointerDown(e) {
      isDragging = true;
      autoRotate = false;
      prevX = e.clientX;
      prevY = e.clientY;
    }
    function onPointerMove(e) {
      if (!isDragging) return;
      const dx = e.clientX - prevX;
      const dy = e.clientY - prevY;
      globeGroup.rotation.y += dx * 0.005;
      globeGroup.rotation.x += dy * 0.005;
      globeGroup.rotation.x = Math.max(-1.1, Math.min(1.1, globeGroup.rotation.x));
      prevX = e.clientX;
      prevY = e.clientY;
    }
    function endDrag() {
      isDragging = false;
    }
    function onClick(e) {
      const rect = renderer.domElement.getBoundingClientRect();
      pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointerNdc, camera);
      const hits = raycaster.intersectObjects(markerObjects);
      if (hits.length > 0) {
        const id = hits[0].object.userData.id;
        if (id) onSelect(id);
      }
    }

    const dom = renderer.domElement;
    dom.style.cursor = "grab";
    dom.addEventListener("pointerdown", (e) => {
      onPointerDown(e);
      dom.style.cursor = "grabbing";
    });
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", () => {
      endDrag();
      dom.style.cursor = "grab";
    });
    dom.addEventListener("click", onClick);

    let raf;
    let t = 0;
    function animate() {
      raf = requestAnimationFrame(animate);
      t += 0.02;
      if (autoRotate) globeGroup.rotation.y += velocityY;

      markerObjects.forEach((obj) => {
        if (obj.userData.isRing) {
          const isSelected = obj.userData.id === stateRef.current.selectedId;
          if (isSelected) {
            const pulse = 1 + 0.6 * ((Math.sin(t * 1.6) + 1) / 2);
            obj.scale.setScalar(pulse);
            obj.material.opacity = 0.7 * (1 - (pulse - 1) / 0.6) + 0.05;
          } else {
            obj.scale.setScalar(1);
            obj.material.opacity = 0;
          }
        } else {
          const isSelected = obj.userData.id === stateRef.current.selectedId;
          obj.scale.setScalar(isSelected ? 1.6 : 1);
        }
      });

      renderer.render(scene, camera);
    }
    animate();

    function handleResize() {
      const w = mount.clientWidth || width;
      const h = mount.clientHeight || height;
      if (w === 0 || h === 0) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    }
    window.addEventListener("resize", handleResize);

    // A ResizeObserver catches layout-driven size changes (e.g. this flex
    // child settling into its final size after the initial paint) that a
    // window "resize" event never fires for — this is what actually fixes
    // the blank/invisible globe on first load.
    let ro;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(() => handleResize());
      ro.observe(mount);
    }
    requestAnimationFrame(handleResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("pointermove", onPointerMove);
      if (ro) ro.disconnect();
      mount.removeChild(renderer.domElement);
      sphereGeo.dispose();
      sphereMat.dispose();
      renderer.dispose();
    };
  }, [conflicts, onSelect, showBases, visualMode]);

  // keep the animate loop's closure aware of the latest selection without re-mounting the scene
  useEffect(() => {
    stateRef.current.selectedId = selectedId;
  }, [selectedId]);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", filter: mode.cssFilter }}>
      <div ref={mountRef} style={{ width: "100%", height: "100%" }} />
      {mode.scanlines && (
        <div
          aria-hidden="true"
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            background:
              "repeating-linear-gradient(rgba(0,0,0,0) 0px, rgba(0,0,0,0) 1px, rgba(0,0,0,0.18) 2px, rgba(0,0,0,0.18) 3px)",
            mixBlendMode: "multiply",
          }}
        />
      )}
    </div>
  );
}

function Ticker() {
  return (
    <div
      style={{
        height: 30,
        borderTop: `1px solid ${C.border}`,
        background: C.surface,
        display: "flex",
        alignItems: "center",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          bottom: 0,
          width: 78,
          background: C.surface,
          borderRight: `1px solid ${C.border}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 10,
          letterSpacing: "0.04em",
          color: C.textSecondary,
          fontFamily: mono,
          zIndex: 2,
        }}
      >
        Sources
      </div>
      <div style={{ marginLeft: 78, whiteSpace: "nowrap", overflow: "hidden", width: "100%" }}>
        <div
          style={{
            display: "inline-flex",
            gap: 40,
            fontFamily: mono,
            fontSize: 11,
            color: C.textSecondary,
            animation: "ticker 38s linear infinite",
            paddingLeft: "100%",
          }}
        >
          {[...TICKER, ...TICKER].map((t, i) => (
            <span key={i}>{t}</span>
          ))}
        </div>
      </div>
      <style>{`
        @keyframes ticker {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
        @media (prefers-reduced-motion: reduce) {
          div[style*="animation"] { animation: none !important; }
        }
      `}</style>
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div
      style={{
        fontSize: 10.5,
        color: C.textSecondary,
        fontFamily: mono,
        marginBottom: 10,
        letterSpacing: "0.03em",
      }}
    >
      {children}
    </div>
  );
}

function TrendTooltip({ active, payload }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div
      style={{
        background: C.canvas,
        border: `1px solid ${C.border}`,
        borderRadius: 6,
        padding: "4px 8px",
        fontFamily: mono,
        fontSize: 11,
        color: C.textPrimary,
      }}
    >
      {payload[0].value.toFixed(1)}
    </div>
  );
}

function SeverityTrend({ c }) {
  const m = SEV_META[c.severity];
  const data = c.history.map((v, i) => ({ i, v }));
  const delta = c.history[c.history.length - 1] - c.history[0];
  const rising = delta > 0.1;
  const falling = delta < -0.1;
  const deltaColor = rising ? C.ember : falling ? C.cyan : C.textSecondary;
  return (
    <div style={{ padding: "12px 18px 14px", borderBottom: `1px solid ${C.border}` }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 4 }}>
        <SectionLabel>7-day severity</SectionLabel>
        <span
          style={{
            fontFamily: mono,
            fontSize: 11,
            fontWeight: 500,
            color: deltaColor,
            display: "inline-flex",
            alignItems: "center",
            gap: 3,
          }}
        >
          {/* Direction glyph carries the signal independent of color, so
              colorblind readers aren't relying on ember-vs-cyan alone. */}
          <span aria-hidden="true">{rising ? "▲" : falling ? "▼" : "▬"}</span>
          {delta > 0 ? "+" : ""}
          {delta.toFixed(1)}
        </span>
      </div>
      <div style={{ height: 48, marginLeft: -4 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id={`grad-${c.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={m.color} stopOpacity={0.35} />
                <stop offset="100%" stopColor={m.color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <YAxis hide domain={["dataMin - 0.5", "dataMax + 0.5"]} />
            <Tooltip content={<TrendTooltip />} cursor={{ stroke: C.border }} />
            <Area
              type="monotone"
              dataKey="v"
              stroke={m.color}
              strokeWidth={1.75}
              fill={`url(#grad-${c.id})`}
              dot={false}
              activeDot={{ r: 3, fill: m.color, stroke: C.canvas, strokeWidth: 1.5 }}
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function ScoreBreakdown({ c, open, onToggle }) {
  const m = SEV_META[c.severity];
  const b = c.breakdown;
  const rows = [
    { label: "Volume", value: b.volume, max: 8 },
    { label: "Keyword", value: b.keyword, max: 3 },
    { label: "Tone", value: b.tone, max: 2 },
  ];
  return (
    <div style={{ position: "relative" }}>
      <button
        onClick={onToggle}
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          padding: "3px 8px",
          borderRadius: RADIUS_SM,
          background: `${m.color}1a`,
          border: "none",
          cursor: "pointer",
        }}
      >
        <SeverityDot severity={c.severity} size={7} />
        <span style={{ fontSize: 11, color: m.color, fontFamily: mono, fontWeight: 500 }}>
          {m.label} · {c.score.toFixed(1)}
        </span>
        <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke={m.color} strokeWidth="3">
          <path d={open ? "M18 15l-6-6-6 6" : "M6 9l6 6 6-6"} />
        </svg>
      </button>
      {open && (
        <div
          style={{
            position: "absolute",
            top: 30,
            left: 0,
            width: 230,
            background: C.canvas,
            border: `1px solid ${C.border}`,
            borderRadius: 10,
            padding: "12px 14px",
            zIndex: 15,
            boxShadow: "0 8px 20px rgba(0,0,0,0.4)",
          }}
        >
          <div style={{ fontFamily: mono, fontSize: 10, color: C.textSecondary, marginBottom: 8, letterSpacing: "0.03em" }}>
            Score components
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {rows.map((r) => (
              <div key={r.label} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 11, color: C.textSecondary, width: 52, flexShrink: 0 }}>{r.label}</span>
                <div style={{ flex: 1, height: 5, background: "rgba(255,255,255,0.06)", borderRadius: 3, overflow: "hidden" }}>
                  <div
                    style={{
                      width: `${(r.value / r.max) * 100}%`,
                      height: "100%",
                      background: m.color,
                      borderRadius: 3,
                    }}
                  />
                </div>
                <span style={{ fontFamily: mono, fontSize: 10.5, color: C.textPrimary, width: 26, textAlign: "right" }}>
                  {r.value.toFixed(1)}
                </span>
              </div>
            ))}
          </div>
          <div
            style={{
              marginTop: 10,
              paddingTop: 9,
              borderTop: `1px solid ${C.border}`,
              fontSize: 10.5,
              color: C.textSecondary,
            }}
          >
            {CONF_META[c.confidence].label}
          </div>
        </div>
      )}
    </div>
  );
}

function DetailPanel({ c, breakdownOpen, onToggleBreakdown }) {
  if (!c) return null;
  const m = SEV_META[c.severity];
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ padding: "16px 18px 14px", borderBottom: `1px solid ${C.border}` }}>
        <div style={{ marginBottom: 8 }}>
          <ScoreBreakdown c={c} open={breakdownOpen} onToggle={onToggleBreakdown} />
        </div>
        <h2 style={{ margin: 0, marginBottom: 2, fontSize: 17, fontWeight: 700, letterSpacing: "0.01em", color: C.textPrimary, fontFamily: display }}>
          {c.name}
        </h2>
        <span style={{ fontSize: 12, color: C.textSecondary }}>{c.region}</span>
      </div>

      <SeverityTrend c={c} />

      <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}` }}>
        <SectionLabel>AI brief</SectionLabel>
        <p style={{ margin: 0, fontSize: 13, lineHeight: 1.55, color: C.textPrimary, fontFamily: body }}>
          {c.summary}
        </p>
      </div>

      <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}`, flex: "0 0 auto" }}>
        <SectionLabel>Timeline</SectionLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {c.timeline.map((item, i) => (
            <div key={i} style={{ display: "flex", gap: 10 }}>
              <span style={{ fontFamily: mono, fontSize: 11, color: C.textSecondary, flexShrink: 0, width: 52 }}>
                {item.t}
              </span>
              <span style={{ fontSize: 12.5, color: C.textPrimary, lineHeight: 1.4, opacity: 0.85 }}>{item.e}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "14px 18px", flex: 1, overflowY: "auto" }}>
        <SectionLabel>Sources ({c.sources.length})</SectionLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {c.sources.map((s, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                fontSize: 12,
                color: C.textPrimary,
                opacity: 0.85,
                padding: "8px 0",
                borderBottom: i < c.sources.length - 1 ? `1px solid ${C.border}` : "none",
              }}
            >
              <span>{s.label}</span>
              <ConfBar conf={s.conf} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ---------- App ----------

function SegmentedControl({ options, value, onChange }) {
  return (
    <div
      role="tablist"
      style={{
        display: "flex",
        background: C.canvas,
        border: `1px solid ${C.border}`,
        borderRadius: RADIUS_SM,
        padding: 3,
        gap: 2,
      }}
    >
      {options.map((opt) => {
        const active = opt.value === value;
        return (
          <button
            key={opt.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(opt.value)}
            style={{
              flex: 1,
              border: "none",
              cursor: "pointer",
              padding: "5px 0",
              borderRadius: RADIUS_SM - 3,
              fontFamily: mono,
              fontSize: 10.5,
              fontWeight: 500,
              letterSpacing: "0.02em",
              color: active ? C.textPrimary : C.textSecondary,
              background: active ? C.surface : "transparent",
              boxShadow: active ? `${C.innerHighlight}, 0 1px 2px rgba(0,0,0,0.3)` : "none",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 5,
              transition: "background 150ms ease-out, color 150ms ease-out",
            }}
          >
            {opt.dot && <SeverityDot severity={opt.dot} size={6} />}
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

function ciiColor(score) {
  if (score >= 7) return C.ember;
  if (score >= 5) return "#B97355";
  return C.cyan;
}

function CountryDossierModal({ code, onClose }) {
  const [tab, setTab] = useState("current");
  const dossier = COUNTRY_DOSSIERS[code];
  if (!dossier) return null;
  const entries = tab === "current" ? dossier.current : dossier.historical;
  const tabColor = tab === "current" ? C.ember : C.cyan;

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.55)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 50,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 420,
          maxWidth: "calc(100vw - 40px)",
          maxHeight: "70vh",
          background: C.surface,
          border: `1px solid ${C.border}`,
          borderRadius: 14,
          boxShadow: "0 20px 50px rgba(0,0,0,0.5)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "14px 18px",
            borderBottom: `1px solid ${C.border}`,
          }}
        >
          <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, fontFamily: display, letterSpacing: "0.01em" }}>
            {dossier.name}
          </h2>
          <button
            onClick={onClose}
            style={{
              border: "none",
              background: "transparent",
              color: C.textSecondary,
              cursor: "pointer",
              fontSize: 18,
              lineHeight: 1,
              padding: 4,
            }}
            aria-label="Close"
          >
            ×
          </button>
        </div>

        <div style={{ display: "flex", padding: "10px 18px 0", gap: 4, borderBottom: `1px solid ${C.border}` }}>
          {[
            { id: "current", label: "Current" },
            { id: "historical", label: "Historical" },
          ].map((t) => {
            const active = t.id === tab;
            const color = t.id === "current" ? C.ember : C.cyan;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                style={{
                  border: "none",
                  background: "transparent",
                  cursor: "pointer",
                  padding: "6px 4px 10px",
                  marginRight: 18,
                  fontFamily: mono,
                  fontSize: 11.5,
                  fontWeight: 500,
                  color: active ? color : C.textSecondary,
                  borderBottom: active ? `2px solid ${color}` : "2px solid transparent",
                  transition: "color 150ms ease-out, border-color 150ms ease-out",
                }}
              >
                {t.label}
              </button>
            );
          })}
        </div>

        <div style={{ padding: "14px 18px", overflowY: "auto", display: "flex", flexDirection: "column", gap: 12 }}>
          {entries.map((e, i) => (
            <div key={i} style={{ borderLeft: `2px solid ${tabColor}44`, paddingLeft: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 500, color: C.textPrimary }}>{e.title}</span>
                <span style={{ fontFamily: mono, fontSize: 10.5, color: C.textSecondary, flexShrink: 0 }}>{e.period}</span>
              </div>
              <p style={{ margin: "4px 0 0", fontSize: 12, color: C.textSecondary, lineHeight: 1.45 }}>{e.note}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CIIStrip({ onSelectCountry }) {
  const sorted = CII.slice().sort((a, b) => b.score - a.score);
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 0,
        padding: "8px 18px",
        borderBottom: `1px solid ${C.border}`,
        background: C.canvas,
        overflowX: "auto",
        flexShrink: 0,
      }}
    >
      <span
        style={{
          fontFamily: mono,
          fontSize: 10,
          color: C.textSecondary,
          letterSpacing: "0.03em",
          marginRight: 14,
          flexShrink: 0,
        }}
      >
        CII
      </span>
      <div style={{ display: "flex", gap: 8 }}>
        {sorted.map((c) => {
          const color = ciiColor(c.score);
          const hasDossier = Boolean(COUNTRY_DOSSIERS[c.code]);
          return (
            <button
              key={c.code}
              onClick={() => hasDossier && onSelectCountry(c.code)}
              title={hasDossier ? `${c.name} — view dossier` : c.name}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                padding: "4px 9px",
                borderRadius: RADIUS_SM,
                border: `1px solid ${C.border}`,
                background: C.surface,
                flexShrink: 0,
                cursor: hasDossier ? "pointer" : "default",
                fontFamily: "inherit",
              }}
            >
              <span style={{ fontFamily: mono, fontSize: 10.5, color: C.textSecondary, fontWeight: 500 }}>
                {c.code}
              </span>
              <span style={{ fontFamily: mono, fontSize: 11, color, fontWeight: 600 }}>{c.score.toFixed(1)}</span>
              {Math.abs(c.delta) >= 0.1 && (
                <span style={{ fontSize: 9.5, color: c.delta > 0 ? C.ember : C.cyan, fontFamily: mono }}>
                  {c.delta > 0 ? "↑" : "↓"}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function TheaterToggle({ value, onChange }) {
  const options = [
    { value: "all", label: "All" },
    { value: "middle-east", label: "Iran / Israel" },
    { value: "eastern-europe", label: "Russia / Ukraine" },
  ];
  return (
    <div
      role="tablist"
      aria-label="Theater"
      style={{
        display: "flex",
        background: C.canvas,
        border: `1px solid ${C.border}`,
        borderRadius: RADIUS_SM,
        padding: 3,
        gap: 2,
      }}
    >
      {options.map((opt) => {
        const active = opt.value === value;
        return (
          <button
            key={opt.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(opt.value)}
            style={{
              border: "none",
              cursor: "pointer",
              padding: "5px 10px",
              borderRadius: RADIUS_SM - 3,
              fontFamily: mono,
              fontSize: 10.5,
              fontWeight: 500,
              whiteSpace: "nowrap",
              color: active ? C.textPrimary : C.textSecondary,
              background: active ? C.surface : "transparent",
              boxShadow: active ? `${C.innerHighlight}, 0 1px 2px rgba(0,0,0,0.3)` : "none",
              transition: "background 150ms ease-out, color 150ms ease-out",
            }}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

function NotificationBell({ escalations, open, onToggle, onSelect }) {
  return (
    <div style={{ position: "relative" }}>
      <button
        onClick={onToggle}
        aria-label="Escalation alerts"
        style={{
          position: "relative",
          width: 30,
          height: 30,
          borderRadius: RADIUS_SM,
          border: `1px solid ${C.border}`,
          background: open ? C.surface : "transparent",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          transition: "background 150ms ease-out",
        }}
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={C.textSecondary} strokeWidth="2">
          <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        {escalations.length > 0 && (
          <span
            style={{
              position: "absolute",
              top: 3,
              right: 3,
              width: 7,
              height: 7,
              borderRadius: "50%",
              background: C.ember,
              border: `1.5px solid ${C.canvas}`,
            }}
          />
        )}
      </button>
      {open && (
        <div
          style={{
            position: "absolute",
            top: 36,
            right: 0,
            width: 260,
            background: C.surface,
            border: `1px solid ${C.border}`,
            borderRadius: 12,
            boxShadow: "0 8px 24px rgba(0,0,0,0.4)",
            zIndex: 20,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              padding: "10px 14px",
              borderBottom: `1px solid ${C.border}`,
              fontSize: 10.5,
              fontFamily: mono,
              color: C.textSecondary,
              letterSpacing: "0.03em",
            }}
          >
            Escalating · {escalations.length}
          </div>
          {escalations.length === 0 ? (
            <div style={{ padding: "16px 14px", fontSize: 12, color: C.textSecondary }}>
              No escalating situations right now.
            </div>
          ) : (
            escalations.map((c) => {
              const m = SEV_META[c.severity];
              return (
                <button
                  key={c.id}
                  onClick={() => onSelect(c.id)}
                  style={{
                    display: "flex",
                    width: "100%",
                    textAlign: "left",
                    alignItems: "center",
                    gap: 8,
                    padding: "9px 14px",
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    borderBottom: `1px solid ${C.border}`,
                  }}
                >
                  <SeverityDot severity={c.severity} size={7} />
                  <span style={{ flex: 1, fontSize: 12, color: C.textPrimary }}>{c.name}</span>
                  <span style={{ fontFamily: mono, fontSize: 11, color: m.color }}>↑ {c.score.toFixed(1)}</span>
                </button>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}

export default function ConflictMonitor() {
  const [selectedId, setSelectedId] = useState(CONFLICTS[2].id);
  const [clock, setClock] = useState(new Date());
  const [filter, setFilter] = useState("all");
  const [theater, setTheater] = useState("all");
  const [bellOpen, setBellOpen] = useState(false);
  const [breakdownOpen, setBreakdownOpen] = useState(false);
  const [showBases, setShowBases] = useState(false);
  const [visualMode, setVisualMode] = useState("default");
  const [dossierCountry, setDossierCountry] = useState(null);

  useEffect(() => {
    const iv = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);

  const theaterScoped = CONFLICTS.filter((c) => theater === "all" || c.theater === theater || c.theater === "global");
  const selected = CONFLICTS.find((c) => c.id === selectedId);
  const highCount = theaterScoped.filter((c) => c.severity === "high").length;
  const timeStr = clock.toISOString().slice(11, 19) + " UTC";

  const filtered = theaterScoped
    .filter((c) => filter === "all" || c.severity === filter)
    .sort((a, b) => b.score - a.score);

  useEffect(() => {
    if (!filtered.find((c) => c.id === selectedId) && filtered.length > 0) {
      setSelectedId(filtered[0].id);
    }
  }, [filter, theater]); // eslint-disable-line react-hooks/exhaustive-deps

  // Escalation log — situations whose trend is "up", newest-updated first (illustrative).
  const escalations = CONFLICTS.filter((c) => c.trend === "up").sort((a, b) => a.updated.localeCompare(b.updated));

  return (
    <div
      style={{
        background: C.canvas,
        color: C.textPrimary,
        fontFamily: body,
        height: "100vh",
        minHeight: 640,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;600;700;800;900&family=Inter:wght@400;500&family=JetBrains+Mono:wght@400;500&display=swap"
      />

      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "13px 18px",
          borderBottom: `1px solid ${C.border}`,
          flexShrink: 0,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ fontSize: 14, fontWeight: 700, letterSpacing: "0.03em", fontFamily: display }}>
            CAM'S CONFLICT MONITOR
          </span>
          <TheaterToggle value={theater} onChange={setTheater} />
          <span
            style={{
              fontSize: 10.5,
              color: C.ember,
              border: `1px solid ${C.ember}33`,
              background: `${C.ember}14`,
              borderRadius: RADIUS_SM,
              padding: "3px 8px",
              fontFamily: mono,
              display: "flex",
              alignItems: "center",
              gap: 6,
              fontWeight: 500,
            }}
          >
            <span
              style={{
                width: 5,
                height: 5,
                borderRadius: "50%",
                background: C.ember,
                display: "inline-block",
              }}
            />
            {highCount} active high
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ fontFamily: mono, fontSize: 12, color: C.textSecondary }}>{timeStr}</span>
          <NotificationBell
            escalations={escalations}
            open={bellOpen}
            onToggle={() => setBellOpen((v) => !v)}
            onSelect={(id) => {
              setSelectedId(id);
              setBellOpen(false);
            }}
          />
        </div>
      </div>

      <CIIStrip onSelectCountry={setDossierCountry} />

      {/* Body */}
      <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
        {/* Left rail */}
        <div
          style={{
            width: 240,
            borderRight: `1px solid ${C.border}`,
            display: "flex",
            flexDirection: "column",
            flexShrink: 0,
          }}
        >
          <div
            style={{
              padding: "10px 14px",
              fontSize: 10.5,
              color: C.textSecondary,
              fontFamily: mono,
              letterSpacing: "0.03em",
              borderBottom: `1px solid ${C.border}`,
            }}
          >
            Tracked · {filtered.length}
          </div>
          <div style={{ padding: "10px 14px", borderBottom: `1px solid ${C.border}` }}>
            <SegmentedControl
              value={filter}
              onChange={setFilter}
              options={[
                { value: "all", label: "All" },
                { value: "high", label: "High", dot: "high" },
                { value: "elevated", label: "Elev.", dot: "elevated" },
                { value: "watch", label: "Watch", dot: "watch" },
              ]}
            />
          </div>
          <div style={{ overflowY: "auto", flex: 1 }}>
            {filtered.length === 0 ? (
              <div style={{ padding: "24px 14px", fontSize: 12, color: C.textSecondary, textAlign: "center" }}>
                No tracked conflicts at this severity.
              </div>
            ) : (
              filtered.map((c) => (
                <RegionRow
                  key={c.id}
                  c={c}
                  active={c.id === selectedId}
                  onClick={() => setSelectedId(c.id)}
                />
              ))
            )}
          </div>
        </div>

        {/* Globe */}
        <div style={{ flex: 1, position: "relative", minWidth: 0, background: C.canvas }}>
          <Globe3D
            conflicts={CONFLICTS}
            selectedId={selectedId}
            onSelect={setSelectedId}
            showBases={showBases}
            visualMode={visualMode}
          />
          <button
            onClick={() => setShowBases((v) => !v)}
            style={{
              position: "absolute",
              top: 12,
              left: 12,
              display: "flex",
              alignItems: "center",
              gap: 6,
              fontSize: 10.5,
              fontFamily: mono,
              color: showBases ? C.textPrimary : C.textSecondary,
              background: showBases ? C.surface : "rgba(17,20,24,0.6)",
              padding: "5px 9px",
              borderRadius: RADIUS_SM,
              border: `1px solid ${C.border}`,
              boxShadow: showBases ? C.innerHighlight : "none",
              cursor: "pointer",
              transition: "background 150ms ease-out, color 150ms ease-out",
            }}
          >
            <span
              style={{
                width: 7,
                height: 7,
                background: showBases ? C.usGreen : C.textSecondary,
                transform: "rotate(45deg)",
                display: "inline-block",
              }}
            />
            Military bases
          </button>
          <button
            onClick={() => {
              const idx = VISUAL_MODE_ORDER.indexOf(visualMode);
              setVisualMode(VISUAL_MODE_ORDER[(idx + 1) % VISUAL_MODE_ORDER.length]);
            }}
            style={{
              position: "absolute",
              top: 46,
              left: 12,
              display: "flex",
              alignItems: "center",
              gap: 6,
              fontSize: 10.5,
              fontFamily: mono,
              fontWeight: 500,
              letterSpacing: "0.04em",
              color: visualMode !== "default" ? C.textPrimary : C.textSecondary,
              background: visualMode !== "default" ? C.surface : "rgba(17,20,24,0.6)",
              padding: "5px 9px",
              borderRadius: RADIUS_SM,
              border: `1px solid ${C.border}`,
              boxShadow: visualMode !== "default" ? C.innerHighlight : "none",
              cursor: "pointer",
              transition: "background 150ms ease-out, color 150ms ease-out",
            }}
            title="Cycle visual mode"
          >
            <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M21 12a9 9 0 1 1-3-6.7" />
              <path d="M21 4v5h-5" />
            </svg>
            {VISUAL_MODES[visualMode].label}
          </button>
          <div
            style={{
              position: "absolute",
              top: 12,
              right: 12,
              fontSize: 10.5,
              color: C.textSecondary,
              fontFamily: mono,
              background: "rgba(17,20,24,0.6)",
              padding: "5px 9px",
              borderRadius: RADIUS_SM,
              border: `1px solid ${C.border}`,
              pointerEvents: "none",
            }}
          >
            drag to rotate
          </div>
          <div
            style={{
              position: "absolute",
              bottom: 12,
              left: 12,
              display: "flex",
              gap: 14,
              background: "rgba(17,20,24,0.75)",
              padding: "7px 12px",
              borderRadius: RADIUS_SM,
              border: `1px solid ${C.border}`,
              boxShadow: C.innerHighlight,
            }}
          >
            {Object.entries(SEV_META).map(([k, m]) => (
              <span
                key={k}
                style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 10.5, color: C.textSecondary, fontFamily: mono }}
              >
                <SeverityDot severity={k} size={6} />
                {m.label}
              </span>
            ))}
            <span style={{ width: 1, alignSelf: "stretch", background: C.border }} />
            <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 10.5, color: C.textSecondary, fontFamily: mono }}>
              <svg width="10" height="10" viewBox="0 0 10 10">
                <circle
                  cx="5"
                  cy="5"
                  r="4"
                  fill="none"
                  stroke={C.textSecondary}
                  strokeWidth="1"
                  strokeDasharray="1.5 1.3"
                />
              </svg>
              Unconfirmed
            </span>
            {showBases && (
              <>
                <span style={{ width: 1, alignSelf: "stretch", background: C.border }} />
                <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 10.5, color: C.textSecondary, fontFamily: mono }}>
                  <span style={{ width: 6, height: 6, background: C.usGreen, transform: "rotate(45deg)", display: "inline-block" }} />
                  US
                </span>
                <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 10.5, color: C.textSecondary, fontFamily: mono }}>
                  <span style={{ width: 6, height: 6, background: C.natoBlue, transform: "rotate(45deg)", display: "inline-block" }} />
                  NATO
                </span>
              </>
            )}
          </div>
        </div>

        {/* Detail */}
        <div
          style={{
            width: 320,
            borderLeft: `1px solid ${C.border}`,
            background: C.surface,
            flexShrink: 0,
            minHeight: 0,
          }}
        >
          <DetailPanel
            c={selected}
            breakdownOpen={breakdownOpen}
            onToggleBreakdown={() => setBreakdownOpen((v) => !v)}
          />
        </div>
      </div>

      <Ticker />

      {dossierCountry && (
        <CountryDossierModal code={dossierCountry} onClose={() => setDossierCountry(null)} />
      )}
    </div>
  );
}
