import ConflictMonitor from './ConflictMonitor'

function App() {
  return <ConflictMonitor />
}

export default App
